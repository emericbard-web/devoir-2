from fastapi import FastAPI
from pydantic import BaseModel

class InputData(BaseModel):
    text: str

app = FastAPI()

@app.get("/")
def root():
    return {"message": "API opérationnelle !"}

@app.post("/predict")
def predict(data: InputData):
    result = data.text.upper()
    return {"input": data.text, "prediction": result}
