# Comment publier ce projet sur GitHub

1. Ouvre ce dossier dans VS Code.
2. Dans un terminal :

   git init  
   git add .  
   git commit -m "Initial commit"

3. Va sur GitHub → Crée un nouveau repository.

4. Suis les instructions "push an existing repository" :

   git remote add origin https://github.com/VOTRE_NOM/VOTRE_REPO.git  
   git branch -M main  
   git push -u origin main

Tu auras maintenant un repo GitHub prêt à cloner.
